//
//  Check3ViewController.swift
//  Demo Swift Excel Xlsx Reader Writer
//
//  Created by tret on 26.08.2018.
//  Copyright © 2018 JoelParkerHenderson.com. All rights reserved.
//

import UIKit
import SearchTextField
class Check3ViewController: BaseViewController {
    let colorplaceholde = UIColor.black
    // save omg
    let fio3 = "fio3"
    let fff3 = "fff3"
    let ooo1 = "ooo1"
    let ooo2 = "ooo2"
    let ooo3 = "ooo3"
    let ooo4 = "ooo4"
    let ooo5 = "ooo5"
    let ooo6 = "ooo6"
    let ooo7 = "ooo7"
    let ooo8 = "ooo8"
    let ooo9 = "ooo9"
    let ooo10 = "ooo10"
    let ooo11 = "ooo11"
    let ooo12 = "ooo12"
    let ooo13 = "ooo13"
    let ooo14 = "ooo14"
    let ooo15 = "ooo15"
    let ooo16 = "ooo16"
    let ooo17 = "ooo17"
    let ooo18 = "ooo18"
    let ooo19 = "ooo19"
    let ooo20 = "ooo20"
    let ooo21 = "ooo21"
    let ooo22 = "ooo22"
    let ooo23 = "ooo23"
    let ooo24 = "ooo24"
    let ooo25 = "ooo25"
    let ooo26 = "ooo26"
    let ooo27 = "ooo27"
    let ooo28 = "ooo28"
    let ooo29 = "ooo29"
    let ooo30 = "ooo30"
    let ooo31 = "ooo31"
    let ooo32 = "ooo32"
    let ooo33 = "ooo33"
    let ooo34 = "ooo34"
    let ooo35 = "ooo35"
    let ooo36 = "ooo36"
    let ooo37 = "ooo37"
    let ooo38 = "ooo38"
    let ooo39 = "ooo39"
    let ooo40 = "ooo40"
    let ooo41 = "ooo41"
    let ooo42 = "ooo42"
    let ooo43 = "ooo43"
    let ooo44 = "ooo44"
    let ooo45 = "ooo45"
    let ooo46 = "ooo46"
    let ooo47 = "ooo47"
    let ooo48 = "ooo48"
    let ooo49 = "ooo49"
    let ooo50 = "ooo50"
    let ooo51 = "ooo51"
    let ooo52 = "ooo52"
    let ooo53 = "ooo53"
    let ooo54 = "ooo54"
    let ooo55 = "ooo55"
    let ooo57 = "ooo57"
    let ooo59 = "ooo59"
    let ooo60 = "ooo60"
    let ooo61 = "ooo61"
    let ooo62 = "ooo62"
    
    
    //sheet 2
    let fio33 = "fio33"
    let oop1 = "oop1"
    let oop2 = "oop2"
    let oop3 = "oop3"
    let oop4 = "oop4"
    let oop5 = "oop5"
    let oop6 = "oop6"
    let oop7 = "oop7"
    let oop8 = "oop8"
    let oop9 = "oop9"
    let oop10 = "oop10"
    let oop11 = "oop11"
    let oop12 = "oop12"
    let oop13 = "oop13"
    let oop14 = "oop14"
    let oop15 = "oop15"
    let oop16 = "oop16"
    let oop17 = "oop17"
    let oop18 = "oop18"
    let oop19 = "oop19"
    let oop20 = "oop20"
    let oop21 = "oop21"
    let oop22 = "oop22"
    let oop23 = "oop23"
    let oop24 = "oop24"
    let oop25 = "oop25"
    let oop26 = "oop26"
    let oop27 = "oop27"
    let oop28 = "oop28"
    let oop29 = "oop29"
    let oop30 = "oop30"
    let oop31 = "oop31"
    let oop32 = "oop32"
    let oop33 = "oop33"
    let oop34 = "oop34"
    let oop35 = "oop35"
    let oop36 = "oop36"
    let oop37 = "oop37"
    let oop38 = "oop38"
    let oop39 = "oop39"
    let oop40 = "oop40"
    let oop41 = "oop41"
    let oop42 = "oop42"
    let oop43 = "oop43"
    let oop44 = "oop44"
    let oop45 = "oop45"
    let oop46 = "oop46"
    let oop47 = "oop47"
    let oop48 = "oop48"
    let oop49 = "oop49"
    let oop50 = "oop50"
    let oop51 = "oop51"
    let oop52 = "oop52"
    let oop53 = "oop53"
    let oop54 = "oop54"
    let oop55 = "oop55"
    let oop56 = "oop56"
    let oop58 = "oop58"
    let oop59 = "oop59"
    let oop60 = "oop60"
    let oop61 = "oop61"
    let oop62 = "oop62"
    
    
    
    var vc = ViewController()
    let kukla = "kukla"
    var editArray = [UITextField]()
    var editArray2 = [UITextField]()
    let userdefault = UserDefaults.standard
    @IBOutlet weak var SearchFIO3: SearchTextField!
    @IBOutlet weak var SearchFIO32: SearchTextField!
    
    //Edit
    @IBOutlet weak var k1: UITextField!
    @IBOutlet weak var k2: UITextField!
    
    @IBOutlet weak var k3: UITextField!
    @IBOutlet weak var k4: UITextField!
    @IBOutlet weak var k5: UITextField!
    @IBOutlet weak var k6: UITextField!
    @IBOutlet weak var k7: UITextField!
    @IBOutlet weak var k8: UITextField!
    @IBOutlet weak var k9: UITextField!
    @IBOutlet weak var k10: UITextField!
    @IBOutlet weak var k11: UITextField!
    @IBOutlet weak var k12: UITextField!
    @IBOutlet weak var k13: UITextField!
    @IBOutlet weak var k14: UITextField!
    @IBOutlet weak var k15: UITextField!
    @IBOutlet weak var k16: UITextField!
    @IBOutlet weak var k17: UITextField!
    @IBOutlet weak var k18: UITextField!
    @IBOutlet weak var k19: UITextField!
    @IBOutlet weak var k20: UITextField!
    @IBOutlet weak var k21: UITextField!
    @IBOutlet weak var k22: UITextField!
    @IBOutlet weak var k23: UITextField!
    @IBOutlet weak var k24: UITextField!
    @IBOutlet weak var k25: UITextField!
    @IBOutlet weak var k26: UITextField!
    @IBOutlet weak var k27: UITextField!
    @IBOutlet weak var k28: UITextField!
    @IBOutlet weak var k29: UITextField!
    @IBOutlet weak var k30: UITextField!
    @IBOutlet weak var k31: UITextField!
    @IBOutlet weak var k32: UITextField!
    @IBOutlet weak var k33: UITextField!
    @IBOutlet weak var k34: UITextField!
    @IBOutlet weak var k35: UITextField!
    @IBOutlet weak var k36: UITextField!
    @IBOutlet weak var k37: UITextField!
    @IBOutlet weak var k38: UITextField!
    @IBOutlet weak var k39: UITextField!
    @IBOutlet weak var k40: UITextField!
    @IBOutlet weak var k41: UITextField!
    @IBOutlet weak var k42: UITextField!
    @IBOutlet weak var k43: UITextField!
    @IBOutlet weak var k44: UITextField!
    @IBOutlet weak var k45: UITextField!
    @IBOutlet weak var k46: UITextField!
    @IBOutlet weak var k47: UITextField!
    @IBOutlet weak var k48: UITextField!
    @IBOutlet weak var k49: UITextField!
    @IBOutlet weak var k50: UITextField!
    @IBOutlet weak var k51: UITextField!
    @IBOutlet weak var k52: UITextField!
    @IBOutlet weak var k53: UITextField!
    @IBOutlet weak var k54: UITextField!
    @IBOutlet weak var k55: UITextField!
    @IBOutlet weak var k57: UITextField!
    @IBOutlet weak var k59: UITextField!
    @IBOutlet weak var k60: UITextField!
    @IBOutlet weak var k61: UITextField!
    @IBOutlet weak var k62: UITextField!
    //sheet 2
    @IBOutlet weak var s1: UITextField!
    @IBOutlet weak var s2: UITextField!
    @IBOutlet weak var s3: UITextField!
    @IBOutlet weak var s4: UITextField!
    @IBOutlet weak var s5: UITextField!
    @IBOutlet weak var s6: UITextField!
    @IBOutlet weak var s7: UITextField!
    @IBOutlet weak var s8: UITextField!
    @IBOutlet weak var s9: UITextField!
    @IBOutlet weak var s10: UITextField!
    @IBOutlet weak var s11: UITextField!
    @IBOutlet weak var s12: UITextField!
    @IBOutlet weak var s13: UITextField!
    @IBOutlet weak var s14: UITextField!
    @IBOutlet weak var s15: UITextField!
    @IBOutlet weak var s16: UITextField!
    @IBOutlet weak var s17: UITextField!
    @IBOutlet weak var s18: UITextField!
    @IBOutlet weak var s19: UITextField!
    @IBOutlet weak var s20: UITextField!
    @IBOutlet weak var s21: UITextField!
    @IBOutlet weak var s22: UITextField!
    @IBOutlet weak var s23: UITextField!
    @IBOutlet weak var s24: UITextField!
    @IBOutlet weak var s25: UITextField!
    @IBOutlet weak var s26: UITextField!
    @IBOutlet weak var s27: UITextField!
    @IBOutlet weak var s28: UITextField!
    @IBOutlet weak var s29: UITextField!
    @IBOutlet weak var s30: UITextField!
    @IBOutlet weak var s31: UITextField!
    @IBOutlet weak var s32: UITextField!
    @IBOutlet weak var s33: UITextField!
    @IBOutlet weak var s34: UITextField!
    @IBOutlet weak var s35: UITextField!
    @IBOutlet weak var s36: UITextField!
    @IBOutlet weak var s37: UITextField!
    @IBOutlet weak var s38: UITextField!
    @IBOutlet weak var s39: UITextField!
    @IBOutlet weak var s40: UITextField!
    @IBOutlet weak var s41: UITextField!
    @IBOutlet weak var s42: UITextField!
    @IBOutlet weak var s43: UITextField!
    @IBOutlet weak var s44: UITextField!
    @IBOutlet weak var s45: UITextField!
    @IBOutlet weak var s46: UITextField!
    @IBOutlet weak var s47: UITextField!
    @IBOutlet weak var s48: UITextField!
    @IBOutlet weak var s49: UITextField!
    @IBOutlet weak var s50: UITextField!
    @IBOutlet weak var s51: UITextField!
    @IBOutlet weak var s52: UITextField!
    @IBOutlet weak var s53: UITextField!
    @IBOutlet weak var s54: UITextField!
    @IBOutlet weak var s55: UITextField!
    @IBOutlet weak var s56: UITextField!
    
    @IBOutlet var txtcoll: [UITextField]!
    
    
    let Usdf = UserDefaults.standard
    //
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addSlideMenuButton()
        placeholdercolor(name:k5)
        placeholdercolor(name:k6)
        placeholdercolor(name:k7)
        placeholdercolor(name:k8)
        placeholdercolor(name:k9)
        placeholdercolor(name:k10)
        placeholdercolor(name:k11)
        placeholdercolor(name:k12)
        placeholdercolor(name:k13)
        placeholdercolor(name:k14)
        placeholdercolor(name:k15)
        placeholdercolor(name:k16)
        placeholdercolor(name:k17)
        placeholdercolor(name:k18)
        placeholdercolor(name:k19)
        placeholdercolor(name:k20)
        placeholdercolor(name:k21)
        placeholdercolor(name:k22)
        placeholdercolor(name:k23)
        placeholdercolor(name:k24)
        placeholdercolor(name:k25)
        placeholdercolor(name:k26)
        placeholdercolor(name:k27)
        placeholdercolor(name:k28)
        placeholdercolor(name:k29)
        placeholdercolor(name:k30)
        placeholdercolor(name:k31)
        placeholdercolor(name:k32)
        placeholdercolor(name:k33)
        placeholdercolor(name:k34)
        placeholdercolor(name:k35)
        placeholdercolor(name:k36)
        placeholdercolor(name:k37)
        placeholdercolor(name:k38)
        placeholdercolor(name:k39)
        placeholdercolor(name:k40)
        placeholdercolor(name:k41)
        placeholdercolor(name:k42)
        placeholdercolor(name:k43)
        placeholdercolor(name:k44)
        placeholdercolor(name:k45)
        placeholdercolor(name:k46)
        placeholdercolor(name:k47)
      //  placeholdercolor(name:k48)
        placeholdercolor(name:k49)
        placeholdercolor(name:k50)
        placeholdercolor(name:k51)
        placeholdercolor(name:k52)
        placeholdercolor(name:k53)
        placeholdercolor(name:k54)
        placeholdercolor(name:k55)
        placeholdercolor(name:k57)
        placeholdercolor(name:k59)
        placeholdercolor(name:k60!)
        placeholdercolor(name:k61)
        placeholdercolor(name:k62)
        
        //s
        placeholdercolor(name:s1)
        placeholdercolor(name:s2)
        placeholdercolor(name:s3)
        placeholdercolor(name:s4)
        placeholdercolor(name:s5)
        placeholdercolor(name:s6)
        placeholdercolor(name:s7)
        placeholdercolor(name:s8)
        placeholdercolor(name:s9)
        placeholdercolor(name:s10)
        placeholdercolor(name:s11)
        placeholdercolor(name:s12)
        placeholdercolor(name:s13)
        placeholdercolor(name:s14)
        placeholdercolor(name:s15)
        placeholdercolor(name:s16)
        placeholdercolor(name:s17)
        placeholdercolor(name:s18)
        placeholdercolor(name:s19)
        placeholdercolor(name:s20)
        placeholdercolor(name:s21)
        placeholdercolor(name:s22)
        placeholdercolor(name:s23)
        placeholdercolor(name:s24)
        placeholdercolor(name:s25)
        placeholdercolor(name:s26)
        placeholdercolor(name:s27)
        placeholdercolor(name:s28)
        placeholdercolor(name:s29)
        placeholdercolor(name:s30)
        placeholdercolor(name:s31)
        placeholdercolor(name:s32)
        placeholdercolor(name:s33)
        placeholdercolor(name:s34)
        placeholdercolor(name:s35)
        placeholdercolor(name:s36)
        placeholdercolor(name:s37)
        placeholdercolor(name:s38)
        placeholdercolor(name:s39)
        placeholdercolor(name:s40)
        placeholdercolor(name:s41)
        placeholdercolor(name:s42)
        placeholdercolor(name:s43)
        placeholdercolor(name:s44)
        placeholdercolor(name:s45)
        placeholdercolor(name:s46)
        placeholdercolor(name:s47)
        placeholdercolor(name:s48)
        placeholdercolor(name:s49)
        placeholdercolor(name:s50)
        placeholdercolor(name:s51)
        placeholdercolor(name:s52)
        placeholdercolor(name:s53)
        placeholdercolor(name:s54)
        placeholdercolor(name:s55)
        placeholdercolor(name:s56)
        
        //fio
        if let oif = userdefault.value(forKey: fio3){
            SearchFIO3.text = oif as? String
        }
        //sht2
        if let oif2 = userdefault.value(forKey: fio33){
            SearchFIO32.text = oif2 as? String
        }
        // edits omg
        if let te1 = userdefault.value(forKey: ooo1){
            k1.text = te1 as? String
        }
        if let te2 = userdefault.value(forKey: ooo2){
            k2.text = te2 as? String
        }
        if let te3 = userdefault.value(forKey: ooo3){
            k3.text = te3 as? String
        }
        if let te4 = userdefault.value(forKey: ooo4){
            k4.text = te4 as? String
        }
        if let te5 = userdefault.value(forKey: ooo5){
            k5.text = te5 as? String
        }
        if let te6 = userdefault.value(forKey: ooo6){
            k6.text = te6 as? String
        }
        if let te7 = userdefault.value(forKey: ooo7){
            k7.text = te7 as? String
        }
        if let te8 = userdefault.value(forKey: ooo8){
            k8.text = te8 as? String
        }
        if let te9 = userdefault.value(forKey: ooo9){
            k9.text = te9 as? String
        }
        if let te10 = userdefault.value(forKey: ooo10){
            k10.text = te10 as? String
        }
        if let te11 = userdefault.value(forKey: ooo11){
            k11.text = te11 as? String
        }
        if let te12 = userdefault.value(forKey: ooo12){
            k12.text = te12 as? String
        }
        if let te13 = userdefault.value(forKey: ooo13){
            k13.text = te13 as? String
        }
        if let te14 = userdefault.value(forKey: ooo14){
            k14.text = te14 as? String
        }
        if let te15 = userdefault.value(forKey: ooo15){
            k15.text = te15 as? String
        }
        if let te16 = userdefault.value(forKey: ooo16){
            k16.text = te16 as? String
        }
        if let te17 = userdefault.value(forKey: ooo17){
            k17.text = te17 as? String
        }
        if let te18 = userdefault.value(forKey: ooo18){
            k18.text = te18 as? String
        }
        if let te19 = userdefault.value(forKey: ooo19){
            k19.text = te19 as? String
        }
        if let te20 = userdefault.value(forKey: ooo20){
            k20.text = te20 as? String
        }
        if let te21 = userdefault.value(forKey: ooo21){
            k21.text = te21 as? String
        }
        if let te22 = userdefault.value(forKey: ooo22){
            k22.text = te22 as? String
        }
        if let te23 = userdefault.value(forKey: ooo23){
            k23.text = te23 as? String
        }
        if let te24 = userdefault.value(forKey: ooo24){
            k24.text = te24 as? String
        }
        if let te25 = userdefault.value(forKey: ooo25){
            k25.text = te25 as? String
        }
        if let te26 = userdefault.value(forKey: ooo26){
            k26.text = te26 as? String
        }
        if let te27 = userdefault.value(forKey: ooo27){
            k27.text = te27 as? String
        }
        if let te28 = userdefault.value(forKey: ooo28){
            k28.text = te28 as? String
        }
        if let te29 = userdefault.value(forKey: ooo29){
            k29.text = te29 as? String
        }
        if let te30 = userdefault.value(forKey: ooo30){
            k30.text = te30 as? String
        }
        if let te31 = userdefault.value(forKey: ooo31){
            k31.text = te31 as? String
        }
        if let te32 = userdefault.value(forKey: ooo32){
            k32.text = te32 as? String
        }
        if let te33 = userdefault.value(forKey: ooo33){
            k33.text = te33 as? String
        }
        if let te34 = userdefault.value(forKey: ooo34){
            k34.text = te34 as? String
        }
        if let te35 = userdefault.value(forKey: ooo35){
            k35.text = te35 as? String
        }
        if let te36 = userdefault.value(forKey: ooo36){
            k36.text = te36 as? String
        }
        if let te37 = userdefault.value(forKey: ooo37){
            k37.text = te37 as? String
        }
        if let te38 = userdefault.value(forKey: ooo38){
            k38.text = te38 as? String
        }
        if let te39 = userdefault.value(forKey: ooo39){
            k39.text = te39 as? String
        }
        if let te40 = userdefault.value(forKey: ooo40){
            k40.text = te40 as? String
        }
        if let te41 = userdefault.value(forKey: ooo41){
            k41.text = te41 as? String
        }
        if let te42 = userdefault.value(forKey: ooo42){
            k42.text = te42 as? String
        }
        if let te43 = userdefault.value(forKey: ooo43){
            k43.text = te43 as? String
        }
        if let te44 = userdefault.value(forKey: ooo44){
            k44.text = te44 as? String
        }
        if let te45 = userdefault.value(forKey: ooo45){
            k45.text = te45 as? String
        }
        if let te46 = userdefault.value(forKey: ooo46){
            k46.text = te46 as? String
        }
        if let te47 = userdefault.value(forKey: ooo47){
            k47.text = te47 as? String
        }
        if let te48 = userdefault.value(forKey: ooo48){
            k48.text = te48 as? String
        }
        if let te49 = userdefault.value(forKey: ooo49){
            k49.text = te49 as? String
        }
        if let te50 = userdefault.value(forKey: ooo50){
            k50.text = te50 as? String
        }
        if let te51 = userdefault.value(forKey: ooo51){
            k51.text = te51 as? String
        }
        if let te52 = userdefault.value(forKey: ooo52){
            k52.text = te52 as? String
        }
        if let te53 = userdefault.value(forKey: ooo53){
            k53.text = te53 as? String
        }
        if let te54 = userdefault.value(forKey: ooo54){
            k54.text = te54 as? String
        }
        if let te55 = userdefault.value(forKey: ooo55){
            k55.text = te55 as? String
        }
        if let te57 = userdefault.value(forKey: ooo57){
            k57.text = te57 as? String
        }
        if let te59 = userdefault.value(forKey: ooo59){
            k59.text = te59 as? String
        }
        if let te60 = userdefault.value(forKey: ooo60){
            k60.text = te60 as? String
        }
        if let te61 = userdefault.value(forKey: ooo61){
            k61.text = te61 as? String
        }
        if let te62 = userdefault.value(forKey: ooo62){
            k62.text = te62 as? String
        }
        // sheet2
        if let et1 = userdefault.value(forKey: oop1){
            s1.text = et1 as? String
        }
        if let et2 = userdefault.value(forKey: oop2){
            s2.text = et2 as? String
        }
        if let et3 = userdefault.value(forKey: oop3){
            s3.text = et3 as? String
        }
        if let et4 = userdefault.value(forKey: oop4){
            s4.text = et4 as? String
        }
        if let et5 = userdefault.value(forKey: oop5){
            s5.text = et5 as? String
        }
        if let et6 = userdefault.value(forKey: oop6){
            s6.text = et6 as? String
        }
        if let et7 = userdefault.value(forKey: oop7){
            s7.text = et7 as? String
        }
        if let et8 = userdefault.value(forKey: oop8){
            s8.text = et8 as? String
        }
        if let et9 = userdefault.value(forKey: oop9){
            s9.text = et9 as? String
        }
        if let et10 = userdefault.value(forKey: oop10){
            s10.text = et10 as? String
        }
        if let et11 = userdefault.value(forKey: oop11){
            s11.text = et11 as? String
        }
        if let et12 = userdefault.value(forKey: oop12){
            s12.text = et12 as? String
        }
        if let et13 = userdefault.value(forKey: oop13){
            s13.text = et13 as? String
        }
        if let et14 = userdefault.value(forKey: oop14){
            s14.text = et14 as? String
        }
        if let et15 = userdefault.value(forKey: oop15){
            s15.text = et15 as? String
        }
        if let et16 = userdefault.value(forKey: oop16){
            s16.text = et16 as? String
        }
        if let et17 = userdefault.value(forKey: oop17){
            s17.text = et17 as? String
        }
        if let et18 = userdefault.value(forKey: oop18){
            s18.text = et18 as? String
        }
        if let et19 = userdefault.value(forKey: oop19){
            s19.text = et19 as? String
        }
        if let et20 = userdefault.value(forKey: oop20){
            s20.text = et20 as? String
        }
        if let et21 = userdefault.value(forKey: oop21){
            s21.text = et21 as? String
        }
        if let et22 = userdefault.value(forKey: oop22){
            s22.text = et22 as? String
        }
        if let et23 = userdefault.value(forKey: oop23){
            s23.text = et23 as? String
        }
        if let et24 = userdefault.value(forKey: oop24){
            s24.text = et24 as? String
        }
        if let et25 = userdefault.value(forKey: oop25){
            s25.text = et25 as? String
        }
        if let et26 = userdefault.value(forKey: oop26){
            s26.text = et26 as? String
        }
        if let et27 = userdefault.value(forKey: oop27){
            s27.text = et27 as? String
        }
        if let et28 = userdefault.value(forKey: oop28){
            s28.text = et28 as? String
        }
        if let et29 = userdefault.value(forKey: oop29){
            s29.text = et29 as? String
        }
        if let et30 = userdefault.value(forKey: oop30){
            s30.text = et30 as? String
        }
        if let et31 = userdefault.value(forKey: oop31){
            s31.text = et31 as? String
        }
        if let et32 = userdefault.value(forKey: oop32){
            s32.text = et32 as? String
        }
        if let et33 = userdefault.value(forKey: oop33){
            s33.text = et33 as? String
        }
        if let et34 = userdefault.value(forKey: oop34){
            s34.text = et34 as? String
        }
        if let et35 = userdefault.value(forKey: oop35){
            s35.text = et35 as? String
        }
        if let et36 = userdefault.value(forKey: oop36){
            s36.text = et36 as? String
        }
        if let et37 = userdefault.value(forKey: oop37){
            s37.text = et37 as? String
        }
        if let et38 = userdefault.value(forKey: oop38){
            s38.text = et38 as? String
        }
        if let et39 = userdefault.value(forKey: oop39){
            s39.text = et39 as? String
        }
        if let et40 = userdefault.value(forKey: oop40){
            s40.text = et40 as? String
        }
        if let et41 = userdefault.value(forKey: oop41){
            s41.text = et41 as? String
        }
        if let et42 = userdefault.value(forKey: oop42){
            s42.text = et42 as? String
        }
        if let et43 = userdefault.value(forKey: oop43){
            s43.text = et43 as? String
        }
        if let et44 = userdefault.value(forKey: oop44){
            s44.text = et44 as? String
        }
        if let et45 = userdefault.value(forKey: oop45){
            s45.text = et45 as? String
        }
        if let et46 = userdefault.value(forKey: oop46){
            s46.text = et46 as? String
        }
        if let et47 = userdefault.value(forKey: oop47){
            s47.text = et47 as? String
        }
        if let et48 = userdefault.value(forKey: oop48){
            s48.text = et48 as? String
        }
        if let et49 = userdefault.value(forKey: oop49){
            s49.text = et49 as? String
        }
        if let et50 = userdefault.value(forKey: oop50){
            s50.text = et50 as? String
        }
        if let et51 = userdefault.value(forKey: oop51){
            s51.text = et51 as? String
        }
        if let et52 = userdefault.value(forKey: oop52){
            
            s52.text = et52 as? String
        }
        if let et53 = userdefault.value(forKey: oop53){
            s53.text = et53 as? String
        }
        if let et54 = userdefault.value(forKey: oop54){
            s54.text = et54 as? String
        }
        if let et55 = userdefault.value(forKey: oop55){
            s55.text = et55 as? String
        }
        if let et56 = userdefault.value(forKey: oop56){
            s56.text = et56 as? String
        }
        //
        connectArray()
        editArray.append(k1)
        editArray.append(k2)
        editArray.append(k3)
        editArray.append(k4)
        editArray.append(k5)
        editArray.append(k6)
        editArray.append(k7)
        editArray.append(k8)
        editArray.append(k9)
        editArray.append(k10)
        editArray.append(k11)
        editArray.append(k12)
        editArray.append(k13)
        editArray.append(k14)
        editArray.append(k15)
        editArray.append(k16)
        editArray.append(k17)
        editArray.append(k18)
        editArray.append(k19)
        editArray.append(k20)
        editArray.append(k21)
        editArray.append(k22)
        editArray.append(k23)
        editArray.append(k24)
        editArray.append(k25)
        editArray.append(k26)
        editArray.append(k27)
        editArray.append(k28)
        editArray.append(k29)
        editArray.append(k30)
        editArray.append(k31)
        editArray.append(k32)
        editArray.append(k33)
        editArray.append(k34)
        editArray.append(k35)
        editArray.append(k36)
        editArray.append(k37)
        editArray.append(k38)
        editArray.append(k39)
        editArray.append(k40)
        editArray.append(k41)
        editArray.append(k42)
        editArray.append(k43)
        editArray.append(k44)
        editArray.append(k45)
        editArray.append(k46)
        editArray.append(k47)
        editArray.append(k48)
        editArray.append(k49)
        editArray.append(k50)
        editArray.append(k51)
        editArray.append(k52)
        editArray.append(k53)
        editArray.append(k54)
        editArray.append(k55)
        editArray.append(k57)
        editArray.append(k59)
        editArray.append(k60)
        editArray.append(k61)
        editArray.append(k62)
        
        //sh 2
        editArray2.append(s1)
        editArray2.append(s2)
        editArray2.append(s3)
        editArray2.append(s4)
        editArray2.append(s5)
        editArray2.append(s6)
        editArray2.append(s7)
        editArray2.append(s8)
        editArray2.append(s9)
        editArray2.append(s10)
        editArray2.append(s11)
        editArray2.append(s12)
        editArray2.append(s13)
        editArray2.append(s14)
        editArray2.append(s15)
        editArray2.append(s16)
        editArray2.append(s17)
        editArray2.append(s18)
        editArray2.append(s19)
        editArray2.append(s20)
        editArray2.append(s21)
        editArray2.append(s22)
        editArray2.append(s23)
        editArray2.append(s24)
        editArray2.append(s25)
        editArray2.append(s26)
        editArray2.append(s27)
        editArray2.append(s28)
        editArray2.append(s29)
        editArray2.append(s30)
        editArray2.append(s31)
        editArray2.append(s32)
        editArray2.append(s33)
        editArray2.append(s34)
        editArray2.append(s35)
        editArray2.append(s36)
        editArray2.append(s37)
        editArray2.append(s38)
        editArray2.append(s39)
        editArray2.append(s40)
        editArray2.append(s41)
        editArray2.append(s42)
        editArray2.append(s43)
        editArray2.append(s44)
        editArray2.append(s45)
        editArray2.append(s46)
        editArray2.append(s47)
        editArray2.append(s48)
        editArray2.append(s49)
        editArray2.append(s50)
        editArray2.append(s51)
        editArray2.append(s52)
        editArray2.append(s53)
        editArray2.append(s54)
        editArray2.append(s55)
        editArray2.append(s56)
        //
        

    }
    @IBAction func add(_ sender: UIButton) {
        if vc.arrayName.contains(SearchFIO3.text!){
            alert4(title: "Добавление пользователя", message: "Не удалось. Пользователь был ранее создан", style: .alert)
        }
        else{
            alert4(title: "Добавление пользователя", message: "Пользователь успешно добавлен", style: .alert)
            vc.arrayName.append(SearchFIO3.text!)
            userdefault.set(vc.arrayName, forKey: vc.nameArray)
        }
        
        connectArray()
        print(vc.arrayName)
    }
    @IBAction func deleteVariable(_ sender: UIButton) {
        if vc.arrayName.contains(SearchFIO3.text!){
            vc.arrayName = vc.arrayName.filter(){$0 != SearchFIO3.text}
            userdefault.set(vc.arrayName, forKey: vc.nameArray)
            alert4(title: "Добавление пользователя", message: "Пользователь успешно удален", style: .alert)
            connectArray()
            SearchFIO3.text = ""
            print(vc.arrayName)
        }
        else{
            alert4(title: "Удаление невозможно", message: "Пользователя нет в списках", style: .alert)
        }
    }
    
    @IBAction func report3(_ sender: UIButton) {
        
        alert3(title: "Отчет сформирован!", message: "iTunes -> общие файлы  -> Demo. Сохранить ли данные в ячейках?", style:  .alert)
    }
    //fio
    @IBAction func ff31(_ sender: SearchTextField) {
        userdefault.set(SearchFIO3.text, forKey: fio3)
        
    }
    //sht 2
    @IBAction func ff32(_ sender: SearchTextField) {
        userdefault.set(SearchFIO32.text, forKey: fio33)
        
    }
    
    //
    //user save field
    
    @IBAction func bl1(_ sender: UITextField) {
        userdefault.set(k1.text, forKey: ooo1)
       
    }
    
    @IBAction func bl2(_ sender: UITextField) {
     userdefault.set(k2.text, forKey: ooo2)
    }
    
    @IBAction func bl3(_ sender: UITextField) {
        userdefault.set(k3.text, forKey: ooo3)
    }
    @IBAction func bl4(_ sender: UITextField) {
        userdefault.set(k4.text, forKey: ooo4)
    }
    @IBAction func bl5(_ sender: UITextField) {
        userdefault.set(k5.text, forKey: ooo5)
    }
    @IBAction func bl6(_ sender: UITextField) {
        userdefault.set(k6.text, forKey: ooo6)
    }
    @IBAction func bl7(_ sender: UITextField) {
        userdefault.set(k7.text, forKey: ooo7)
    }
    @IBAction func bl8(_ sender: UITextField) {
        userdefault.set(k8.text, forKey: ooo8)
    }
    @IBAction func bl9(_ sender: UITextField) {
userdefault.set(k9.text, forKey: ooo9)
        
    }
    @IBAction func bl10(_ sender: UITextField) {
    userdefault.set(k10.text, forKey: ooo10)}
    @IBAction func bl11(_ sender: UITextField) {
    userdefault.set(k11.text, forKey: ooo11)}
    @IBAction func bl12(_ sender: UITextField) {
    userdefault.set(k12.text, forKey: ooo12)}
    @IBAction func bl13(_ sender: UITextField) {
    userdefault.set(k13.text, forKey: ooo13)}
    @IBAction func bl14(_ sender: UITextField) {
    userdefault.set(k14.text, forKey: ooo14)}
    @IBAction func bl15(_ sender: UITextField) {
    userdefault.set(k15.text, forKey: ooo15)}
    @IBAction func bl16(_ sender: UITextField) {
    userdefault.set(k16.text, forKey: ooo16)}
    @IBAction func bl17(_ sender: UITextField) {
    userdefault.set(k17.text, forKey: ooo17)}
    @IBAction func bl18(_ sender: UITextField) {
    userdefault.set(k18.text, forKey: ooo18)}
    @IBAction func bl19(_ sender: UITextField) {
    userdefault.set(k19.text, forKey: ooo19)}
    @IBAction func bl20(_ sender: UITextField) {
        userdefault.set(k20.text, forKey: ooo20)
    }
    @IBAction func bl21(_ sender: UITextField) {
        userdefault.set(k21.text, forKey: ooo21)
    }
    @IBAction func bl22(_ sender: UITextField) {
        userdefault.set(k22.text, forKey: ooo22)
    }
    @IBAction func bl23(_ sender: UITextField) {
        userdefault.set(k23.text, forKey: ooo23)
    }
    @IBAction func bl24(_ sender: UITextField) {
        userdefault.set(k24.text, forKey: ooo24)
    }
    @IBAction func bl25(_ sender: UITextField) {
        userdefault.set(k25.text, forKey: ooo25)
    }
    @IBAction func bl26(_ sender: UITextField) {
        userdefault.set(k26.text, forKey: ooo26)
    }
    @IBAction func bl27(_ sender: UITextField) {
        userdefault.set(k27.text, forKey: ooo27)
    }
    @IBAction func bl28(_ sender: UITextField) {
        userdefault.set(k28.text, forKey: ooo28)
    }
    @IBAction func bl29(_ sender: UITextField) {
        userdefault.set(k29.text, forKey: ooo29)
    }
    @IBAction func bl30(_ sender: UITextField) {
        userdefault.set(k30.text, forKey: ooo30)
    }
    @IBAction func bl31(_ sender: UITextField) {
        userdefault.set(k31.text, forKey: ooo31)
    }
    @IBAction func bl32(_ sender: UITextField) {
        userdefault.set(k32.text, forKey: ooo32)
    }
    @IBAction func bl33(_ sender: UITextField) {
        userdefault.set(k33.text, forKey: ooo33)
    }
    @IBAction func bl34(_ sender: UITextField) {
        userdefault.set(k34.text, forKey: ooo34)
    }
    @IBAction func bl35(_ sender: UITextField) {
        userdefault.set(k35.text, forKey: ooo35)
    }
    @IBAction func bl36(_ sender: UITextField) {
        userdefault.set(k36.text, forKey: ooo36)
    }
    @IBAction func bl37(_ sender: UITextField) {
        userdefault.set(k37.text, forKey: ooo37)
    }
    @IBAction func bl38(_ sender: UITextField) {
        userdefault.set(k38.text, forKey: ooo38)
    }
    @IBAction func bl39(_ sender: UITextField) {
        userdefault.set(k39.text, forKey: ooo39)
    }
    @IBAction func bl40(_ sender: UITextField) {
        userdefault.set(k40.text, forKey: ooo40)
    }
    @IBAction func bl41(_ sender: UITextField) {
        userdefault.set(k41.text, forKey: ooo41)
    }
    @IBAction func bl42(_ sender: UITextField) {
        userdefault.set(k42.text, forKey: ooo42)
    }
    @IBAction func bl43(_ sender: UITextField) {
        userdefault.set(k43.text, forKey: ooo43)
    }
    @IBAction func bl44(_ sender: UITextField) {
        userdefault.set(k44.text, forKey: ooo44)
    }
    @IBAction func bl45(_ sender: UITextField) {
        userdefault.set(k45.text, forKey: ooo45)
    }
    @IBAction func bl46(_ sender: UITextField) {
        userdefault.set(k46.text, forKey: ooo46)
    }
    @IBAction func bl47(_ sender: UITextField) {
        userdefault.set(k47.text, forKey: ooo47)
    }
    @IBAction func bl48(_ sender: UITextField) {
        userdefault.set(k48.text, forKey: ooo48)
    }
    @IBAction func bl49(_ sender: UITextField) {
        userdefault.set(k49.text, forKey: ooo49)
    }
    @IBAction func bl50(_ sender: UITextField) {
        userdefault.set(k50.text, forKey: ooo50)
    }
    @IBAction func bl51(_ sender: UITextField) {
        userdefault.set(k51.text, forKey: ooo51)
    }
    @IBAction func bl52(_ sender: UITextField) {
        userdefault.set(k52.text, forKey: ooo52)
    }
    @IBAction func bl53(_ sender: UITextField) {
        userdefault.set(k53.text, forKey: ooo53)
    }
    @IBAction func bl54(_ sender: UITextField) {
        userdefault.set(k54.text, forKey: ooo54)
    }
    @IBAction func bl55(_ sender: UITextField) {
        userdefault.set(k55.text, forKey: ooo55)
    }
  
    @IBAction func bl57(_ sender: UITextField) {
        userdefault.set(k57.text, forKey: ooo57)
    }
    
    @IBAction func bl59(_ sender: UITextField) {
        userdefault.set(k59.text, forKey: ooo59)
    }
    @IBAction func bl60(_ sender: UITextField) {
        userdefault.set(k60.text, forKey: ooo60)
    }
    @IBAction func bl61(_ sender: UITextField) {
        userdefault.set(k61.text, forKey: ooo61)
    }
    @IBAction func bl62(_ sender: UITextField) {
        userdefault.set(k62.text, forKey: ooo62)
    }
    //sheet 2
    @IBAction func bc1(_ sender: UITextField) {
        userdefault.set(s1.text, forKey: oop1)
        
    }
    
    @IBAction func bc2(_ sender: UITextField) {
        userdefault.set(s2.text, forKey: oop2)
    }
    
    @IBAction func bc3(_ sender: UITextField) {
        userdefault.set(s3.text, forKey: oop3)
    }
    @IBAction func bc4(_ sender: UITextField) {
        userdefault.set(s4.text, forKey: oop4)
    }
    @IBAction func bc5(_ sender: UITextField) {
        userdefault.set(s5.text, forKey: oop5)
    }
    @IBAction func bc6(_ sender: UITextField) {
        userdefault.set(s6.text, forKey: oop6)
    }
    @IBAction func bc7(_ sender: UITextField) {
        userdefault.set(s7.text, forKey: oop7)
    }
    @IBAction func bc8(_ sender: UITextField) {
        userdefault.set(s8.text, forKey: oop8)
    }
    @IBAction func bc9(_ sender: UITextField) {
        userdefault.set(s9.text, forKey: oop9)
        
    }
    @IBAction func bc10(_ sender: UITextField) {
        userdefault.set(s10.text, forKey: oop10)}
    @IBAction func bc11(_ sender: UITextField) {
        userdefault.set(s11.text, forKey: oop11)}
    @IBAction func bc12(_ sender: UITextField) {
        userdefault.set(s12.text, forKey: oop12)}
    @IBAction func bc13(_ sender: UITextField) {
        userdefault.set(s13.text, forKey: oop13)}
    @IBAction func bc14(_ sender: UITextField) {
        userdefault.set(s14.text, forKey: oop14)}
    @IBAction func bc15(_ sender: UITextField) {
        userdefault.set(s15.text, forKey: oop15)}
    @IBAction func bc16(_ sender: UITextField) {
        userdefault.set(s16.text, forKey: oop16)}
    @IBAction func bc17(_ sender: UITextField) {
        userdefault.set(s17.text, forKey: oop17)}
    @IBAction func bc18(_ sender: UITextField) {
        userdefault.set(s18.text, forKey: oop18)}
    @IBAction func bc19(_ sender: UITextField) {
        userdefault.set(s19.text, forKey: oop19)}
    @IBAction func bc20(_ sender: UITextField) {
        userdefault.set(s20.text, forKey: oop20)
    }
    @IBAction func bc21(_ sender: UITextField) {
        userdefault.set(s21.text, forKey: oop21)
    }
    @IBAction func bc22(_ sender: UITextField) {
        userdefault.set(s22.text, forKey: oop22)
    }
    @IBAction func bc23(_ sender: UITextField) {
        userdefault.set(s23.text, forKey: oop23)
    }
    @IBAction func bc24(_ sender: UITextField) {
        userdefault.set(s24.text, forKey: oop24)
    }
    @IBAction func bc25(_ sender: UITextField) {
        userdefault.set(s25.text, forKey: oop25)
    }
    @IBAction func bc26(_ sender: UITextField) {
        userdefault.set(s26.text, forKey: oop26)
    }
    @IBAction func bc27(_ sender: UITextField) {
        userdefault.set(s27.text, forKey: oop27)
    }
    @IBAction func bc28(_ sender: UITextField) {
        userdefault.set(s28.text, forKey: oop28)
    }
    @IBAction func bc29(_ sender: UITextField) {
        userdefault.set(s29.text, forKey: oop29)
    }
    @IBAction func bc30(_ sender: UITextField) {
        userdefault.set(s30.text, forKey: oop30)
    }
    @IBAction func bc31(_ sender: UITextField) {
        userdefault.set(s31.text, forKey: oop31)
    }
    @IBAction func bc32(_ sender: UITextField) {
        userdefault.set(s32.text, forKey: oop32)
    }
    @IBAction func bc33(_ sender: UITextField) {
        userdefault.set(s33.text, forKey: oop33)
    }
    @IBAction func bc34(_ sender: UITextField) {
        userdefault.set(s34.text, forKey: oop34)
    }
    @IBAction func bc35(_ sender: UITextField) {
        userdefault.set(s35.text, forKey: oop35)
    }
    @IBAction func bc36(_ sender: UITextField) {
        userdefault.set(s36.text, forKey: oop36)
    }
    @IBAction func bc37(_ sender: UITextField) {
        userdefault.set(s37.text, forKey: oop37)
    }
    @IBAction func bc38(_ sender: UITextField) {
        userdefault.set(s38.text, forKey: oop38)
    }
    @IBAction func bc39(_ sender: UITextField) {
        userdefault.set(s39.text, forKey: oop39)
    }
    @IBAction func bc40(_ sender: UITextField) {
        userdefault.set(s40.text, forKey: oop40)
    }
    @IBAction func bc41(_ sender: UITextField) {
        userdefault.set(s41.text, forKey: oop41)
    }
    @IBAction func bc42(_ sender: UITextField) {
        userdefault.set(s42.text, forKey: oop42)
    }
    @IBAction func bc43(_ sender: UITextField) {
        userdefault.set(s43.text, forKey: oop43)
    }
    @IBAction func bc44(_ sender: UITextField) {
        userdefault.set(s44.text, forKey: oop44)
    }
    @IBAction func bc45(_ sender: UITextField) {
        userdefault.set(s45.text, forKey: oop45)
    }
    @IBAction func bc46(_ sender:
        
        UITextField) {
        userdefault.set(s46.text, forKey: oop46)
    }
    @IBAction func bc47(_ sender: UITextField) {
        userdefault.set(s47.text, forKey: oop47)
    }
    @IBAction func bc48(_ sender: UITextField) {
        userdefault.set(s48.text, forKey: oop48)
    }
    @IBAction func bc49(_ sender: UITextField) {
        userdefault.set(s49.text, forKey: oop49)
    }
    @IBAction func bc50(_ sender: UITextField) {
        userdefault.set(s50.text, forKey: oop50)
    }
    @IBAction func bc51(_ sender: UITextField) {
        userdefault.set(s51.text, forKey: oop51)
    }
    @IBAction func bc52(_ sender: UITextField) {
        userdefault.set(s52.text, forKey: oop52)
    }
    @IBAction func bc53(_ sender: UITextField) {
        userdefault.set(s53.text, forKey: oop53)
    }
    @IBAction func bc54(_ sender: UITextField) {
        userdefault.set(s54.text, forKey: oop54)
    }
    @IBAction func bc55(_ sender: UITextField) {
        userdefault.set(s55.text, forKey: oop55)
    }
    
    @IBAction func bc56(_ sender: UITextField) {
        userdefault.set(s56.text, forKey: oop56)
    }
    
    //
    
    func alert3(title:String, message: String, style: UIAlertControllerStyle)  {
        let alert = UIAlertController(title: title, message: message, preferredStyle: style)
        alert.addAction(UIAlertAction(title: "Отмена", style: .default, handler: { (act) in
//            self.txtcoll[0...2].forEach({ (field) in
//                let us = UserDefaults.standard
//                us.setValue(field, forKey: "123hh")
//            })
        
        }))
        
        alert.addAction(UIAlertAction(title: "Продолжить", style: .default, handler: { (act) in
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = DateFormatter.Style.short
            let convertedDate = dateFormatter.string(from: Date())
            let path: String = Bundle.main.path(forResource: "materialsandpod", ofType: "xlsx")!
            let spreadsheet: BRAOfficeDocumentPackage = BRAOfficeDocumentPackage.open(path)
            let sheet: BRASheet = spreadsheet.workbook.sheets[0] as! BRASheet
            let worksheet: BRAWorksheet = spreadsheet.workbook.worksheets[0] as! BRAWorksheet
            
            let worksheet2: BRAWorksheet = spreadsheet.workbook.worksheets[1] as! BRAWorksheet
            //ED Cell 1 sheet
            let ed1: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "D11")
            let date1: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "B11")
            let kk1: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G17")
            let kk2: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G18")
            let kk3: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G19")
            let kk4: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G20")
            let kk5: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G21")
            let kk6: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G22")
            let kk7: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G23")
            let kk8: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G24")
            let kk9: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G25")
            let kk10: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G26")
            let kk11: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G27")
            let kk12: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G28")
            let kk13: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G29")
            let kk14: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G30")
            let kk15: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G31")
            let kk16: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G32")
            let kk17: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G33")
            let kk18: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G34")
            let kk19: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G35")
            let kk20: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G36")
            let kk21: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G37")
            let kk22: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G38")
            let kk23: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G39")
            let kk24: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G40")
            let kk25: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G41")
            let kk26: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G42")
            let kk27: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G43")
            let kk28: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G44")
            let kk29: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G45")
            let kk30: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G46")
            let kk31: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G47")
            let kk32: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G48")
            let kk33: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G49")
            let kk34: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G50")
            let kk35: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G51")
            let kk36: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G52")
            let kk37: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G53")
            let kk38: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G54")
            let kk39: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G55")
            let kk40: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G56")
            let kk41: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G57")
            let kk42: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G58")
            let kk43: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G59")
            let kk44: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G60")
            let kk45: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G61")
            let kk46: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G62")
            let kk47: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G63")
            let kk48: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G64")
            let kk49: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G65")
            let kk50: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G66")
            let kk51: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G67")
            let kk52: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G68")
            let kk53: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G69")
            let kk54: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G70")
            let kk55: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G71")
            let kk57: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G72")
            let kk59: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G73")
            let kk60: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G74")
            let kk61: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G75")
            let kk62: BRACell = worksheet.cellOrFirstCellInMergeCell(forCellReference: "G76")
            //2sheet
            let ed2: BRACell = worksheet2.cellOrFirstCellInMergeCell(forCellReference: "D11")
            let date2: BRACell = worksheet2.cellOrFirstCellInMergeCell(forCellReference: "B11")
            
            let kkk1: BRACell = worksheet2.cell(forCellReference: "F17")
            let kkk2: BRACell = worksheet2.cell(forCellReference: "F18")
            let kkk3: BRACell = worksheet2.cell(forCellReference: "F19")
            let kkk4: BRACell = worksheet2.cell(forCellReference: "F20")
            let kkk5: BRACell = worksheet2.cell(forCellReference: "F21")
            let kkk6: BRACell = worksheet2.cell(forCellReference: "F22")
            let kkk7: BRACell = worksheet2.cell(forCellReference: "F23")
            let kkk8: BRACell = worksheet2.cell(forCellReference: "F24")
            let kkk9: BRACell = worksheet2.cell(forCellReference: "F25")
            let kkk10: BRACell = worksheet2.cell(forCellReference: "F26")
            let kkk11: BRACell = worksheet2.cell(forCellReference: "F27")
            let kkk12: BRACell = worksheet2.cell(forCellReference: "F28")
            let kkk13: BRACell = worksheet2.cell(forCellReference: "F29")
            let kkk14: BRACell = worksheet2.cell(forCellReference: "F30")
            let kkk15: BRACell = worksheet2.cell(forCellReference: "F31")
            let kkk16: BRACell = worksheet2.cell(forCellReference: "F32")
            let kkk17: BRACell = worksheet2.cell(forCellReference: "F33")
            let kkk18: BRACell = worksheet2.cell(forCellReference: "F34")
            let kkk19: BRACell = worksheet2.cell(forCellReference: "F35")
            let kkk20: BRACell = worksheet2.cell(forCellReference: "F36")
            let kkk21: BRACell = worksheet2.cell(forCellReference: "F37")
            let kkk22: BRACell = worksheet2.cell(forCellReference: "F38")
            let kkk23: BRACell = worksheet2.cell(forCellReference: "F39")
            let kkk24: BRACell = worksheet2.cell(forCellReference: "F40")
            let kkk25: BRACell = worksheet2.cell(forCellReference: "F41")
            let kkk26: BRACell = worksheet2.cell(forCellReference: "F42")
            let kkk27: BRACell = worksheet2.cell(forCellReference: "F43")
            let kkk28: BRACell = worksheet2.cell(forCellReference: "F44")
            let kkk29: BRACell = worksheet2.cell(forCellReference: "F45")
            let kkk30: BRACell = worksheet2.cell(forCellReference: "F46")
            let kkk31: BRACell = worksheet2.cell(forCellReference: "F47")
            let kkk32: BRACell = worksheet2.cell(forCellReference: "F48")
            let kkk33: BRACell = worksheet2.cell(forCellReference: "F49")
            let kkk34: BRACell = worksheet2.cell(forCellReference: "F50")
            let kkk35: BRACell = worksheet2.cell(forCellReference: "F51")
            let kkk36: BRACell = worksheet2.cell(forCellReference: "F52")
            let kkk37: BRACell = worksheet2.cell(forCellReference: "F53")
            let kkk38: BRACell = worksheet2.cell(forCellReference: "F54")
            let kkk39: BRACell = worksheet2.cell(forCellReference: "F55")
            let kkk40: BRACell = worksheet2.cell(forCellReference: "F56")
            let kkk41: BRACell = worksheet2.cell(forCellReference: "F57")
            let kkk42: BRACell = worksheet2.cell(forCellReference: "F58")
            let kkk43: BRACell = worksheet2.cell(forCellReference: "F59")
            let kkk44: BRACell = worksheet2.cell(forCellReference: "F60")
            let kkk45: BRACell = worksheet2.cell(forCellReference: "F61")
            let kkk46: BRACell = worksheet2.cell(forCellReference: "F62")
            let kkk47: BRACell = worksheet2.cell(forCellReference: "F63")
            let kkk48: BRACell = worksheet2.cell(forCellReference: "F64")
            let kkk49: BRACell = worksheet2.cell(forCellReference: "F65")
            let kkk50: BRACell = worksheet2.cell(forCellReference: "F66")
            let kkk51: BRACell = worksheet2.cell(forCellReference: "F67")
            let kkk52: BRACell = worksheet2.cell(forCellReference: "F68")
            let kkk53: BRACell = worksheet2.cell(forCellReference: "F69")
            let kkk54: BRACell = worksheet2.cell(forCellReference: "F70")
            let kkk55: BRACell = worksheet2.cell(forCellReference: "F71")
            let kkk56: BRACell = worksheet2.cell(forCellReference: "F72")
            // sheet1
            let arrKK = [kk1,
                         kk2,
                         kk3,
                         kk4,
                         kk5,
                         kk6,
                         kk7,
                         kk8,
                         kk9,
                         kk10,
                         kk11,
                         kk12,
                         kk13,
                         kk14,
                         kk15,
                         kk16,
                         kk17,
                         kk18,
                         kk19,
                         kk20,
                         kk21,
                         kk22,
                         kk23,
                         kk24,
                         kk25,
                         kk26,
                         kk27,
                         kk28,
                         kk29,
                         kk30,
                         kk31,
                         kk32,
                         kk33,
                         kk34,
                         kk35,
                         kk36,
                         kk37,
                         kk38,
                         kk39,
                         kk40,
                         kk41,
                         kk42,
                         kk43,
                         kk44,
                         kk45,
                         kk46,
                         kk47,
                         kk48,
                         kk49,
                         kk50,
                         kk51,
                         kk52,
                         kk53,
                         kk54,
                         kk55,
                         kk57,
                         kk59,
                         kk60,
                         kk61,
                         kk62]
            //sheet2 2
            let arrKKK2 = [kkk1,
                           kkk2,
                           kkk3,
                           kkk4,
                           kkk5,
                           kkk6,
                           kkk7,
                           kkk8,
                           kkk9,
                           kkk10,
                           kkk11,
                           kkk12,
                           kkk13,
                           kkk14,
                           kkk15,
                           kkk16,
                           kkk17,
                           kkk18,
                           kkk19,
                           kkk20,
                           kkk21,
                           kkk22,
                           kkk23,
                           kkk24,
                           kkk25,
                           kkk26,
                           kkk27,
                           kkk28,
                           kkk29,
                           kkk30,
                           kkk31,
                           kkk32,
                           kkk33,
                           kkk34,
                           kkk35,
                           kkk36,
                           kkk37,
                           kkk38,
                           kkk39,
                           kkk40,
                           kkk41,
                           kkk42,
                           kkk43,
                           kkk44,
                           kkk45,
                           kkk46,
                           kkk47,
                           kkk48,
                           kkk49,
                           kkk50,
                           kkk51,
                           kkk52,
                           kkk53,
                           kkk54,
                           kkk55,
                           kkk56]
            //
            ed1.setStringValue("Фамилия "+self.SearchFIO3.text!)
            date1.setStringValue("Дата проведения "+convertedDate)
            ed2.setStringValue("Фамилия "+self.SearchFIO32.text!)
            date2.setStringValue("Дата проведения "+convertedDate)
            
            //XZ
            for (index,cell) in arrKK.enumerated() {
                cell.setStringValue(self.editArray[index].text ?? "")
            }
            for (index,cell) in arrKKK2.enumerated() {
                cell.setStringValue(self.editArray2[index].text ?? "")
            }
            let fileManager = FileManager.default
            
            let documentsUrl = fileManager.urls(for: .documentDirectory,
                                                in: .userDomainMask)
            
            guard documentsUrl.count != 0 else {
                return // Could not find documents URL
            }
            
            let finalReportURL = documentsUrl.first!.appendingPathComponent("report-\(Date()).xlsx")
            
            spreadsheet.save(as: finalReportURL.path)
            
            print(finalReportURL.path)
            self.SearchFIO3.text = ""

            self.txtcoll.forEach({ (field) in
                field.text = ""
                self.led()
            })
            
        }))
        self.present(alert, animated: true, completion: nil)
        
   //     let alert = UIAlertController(title: title, message: message, preferredStyle: style)
     //   let Action = UIAlertAction(title: "Ok", style: .default, handler: {(action) in
     //       alert.dismiss(animated: true, completion: nil)
     //       print("Ok")
     //   })
     //   alert.addAction(Action)
     //   self.present(alert, animated: true, completion: nil)
    }
    func alert4(title:String, message: String, style: UIAlertControllerStyle)  {
        let alert4 = UIAlertController(title: title, message: message, preferredStyle: style)
       
        
        alert4.addAction(UIAlertAction(title: "Продолжить", style: .default, handler: { (act) in
            
            
        }))
        self.present(alert4, animated: true, completion: nil)
        
        //     let alert = UIAlertController(title: title, message: message, preferredStyle: style)
        //   let Action = UIAlertAction(title: "Ok", style: .default, handler: {(action) in
        //       alert.dismiss(animated: true, completion: nil)
        //       print("Ok")
        //   })
        //   alert.addAction(Action)
        //   self.present(alert, animated: true, completion: nil)
    }
    
    func placeholdercolor(name:UITextField){
        name.attributedPlaceholder = NSAttributedString(string: name.placeholder!, attributes: [NSForegroundColorAttributeName : colorplaceholde])
        
    }
    func led(){
       //sh 1
        userdefault.removeObject(forKey: ooo1)
        userdefault.removeObject(forKey: ooo2)
        userdefault.removeObject(forKey: ooo3)
        userdefault.removeObject(forKey: ooo4)
        userdefault.removeObject(forKey: ooo5)
        userdefault.removeObject(forKey: ooo6)
        userdefault.removeObject(forKey: ooo7)
        userdefault.removeObject(forKey: ooo8)
        userdefault.removeObject(forKey: ooo9)
        userdefault.removeObject(forKey: ooo10)
        //20
        userdefault.removeObject(forKey: ooo11)
        userdefault.removeObject(forKey: ooo12)
        userdefault.removeObject(forKey: ooo13)
        userdefault.removeObject(forKey: ooo14)
        userdefault.removeObject(forKey: ooo15)
        userdefault.removeObject(forKey: ooo16)
        userdefault.removeObject(forKey: ooo17)
        userdefault.removeObject(forKey: ooo18)
        userdefault.removeObject(forKey: ooo19)
        userdefault.removeObject(forKey: ooo20)
        //30
        userdefault.removeObject(forKey: ooo21)
        userdefault.removeObject(forKey: ooo22)
        userdefault.removeObject(forKey: ooo23)
        userdefault.removeObject(forKey: ooo24)
        userdefault.removeObject(forKey: ooo25)
        userdefault.removeObject(forKey: ooo26)
        userdefault.removeObject(forKey: ooo27)
        userdefault.removeObject(forKey: ooo28)
        userdefault.removeObject(forKey: ooo29)
        userdefault.removeObject(forKey: ooo30)
        //40
        userdefault.removeObject(forKey: ooo31)
        userdefault.removeObject(forKey: ooo32)
        userdefault.removeObject(forKey: ooo33)
        userdefault.removeObject(forKey: ooo34)
        userdefault.removeObject(forKey: ooo35)
        userdefault.removeObject(forKey: ooo36)
        userdefault.removeObject(forKey: ooo37)
        userdefault.removeObject(forKey: ooo38)
        userdefault.removeObject(forKey: ooo39)
        userdefault.removeObject(forKey: ooo40)
        //50
        userdefault.removeObject(forKey: ooo41)
        userdefault.removeObject(forKey: ooo42)
        userdefault.removeObject(forKey: ooo43)
        userdefault.removeObject(forKey: ooo44)
        userdefault.removeObject(forKey: ooo45)
        userdefault.removeObject(forKey: ooo46)
        userdefault.removeObject(forKey: ooo47)
        userdefault.removeObject(forKey: ooo48)
        userdefault.removeObject(forKey: ooo49)
        userdefault.removeObject(forKey: ooo50)
        //60
        userdefault.removeObject(forKey: ooo51)
        userdefault.removeObject(forKey: ooo52)
        userdefault.removeObject(forKey: ooo53)
        userdefault.removeObject(forKey: ooo54)
        userdefault.removeObject(forKey: ooo55)
        userdefault.removeObject(forKey: ooo57)
        userdefault.removeObject(forKey: ooo59)
        userdefault.removeObject(forKey: ooo60)
        //70
        userdefault.removeObject(forKey: ooo61)
        userdefault.removeObject(forKey: ooo62)
        //
        
        //sh2
        
        userdefault.removeObject(forKey: oop1)
        userdefault.removeObject(forKey: oop2)
        userdefault.removeObject(forKey: oop3)
        userdefault.removeObject(forKey: oop4)
        userdefault.removeObject(forKey: oop5)
        userdefault.removeObject(forKey: oop6)
        userdefault.removeObject(forKey: oop7)
        userdefault.removeObject(forKey: oop8)
        userdefault.removeObject(forKey: oop9)
        userdefault.removeObject(forKey: oop10)
        //20
        userdefault.removeObject(forKey: oop11)
        userdefault.removeObject(forKey: oop12)
        userdefault.removeObject(forKey: oop13)
        userdefault.removeObject(forKey: oop14)
        userdefault.removeObject(forKey: oop15)
        userdefault.removeObject(forKey: oop16)
        userdefault.removeObject(forKey: oop17)
        userdefault.removeObject(forKey: oop18)
        userdefault.removeObject(forKey: oop19)
        userdefault.removeObject(forKey: oop20)
        //30
        userdefault.removeObject(forKey: oop21)
        userdefault.removeObject(forKey: oop22)
        userdefault.removeObject(forKey: oop23)
        userdefault.removeObject(forKey: oop24)
        userdefault.removeObject(forKey: oop25)
        userdefault.removeObject(forKey: oop26)
        userdefault.removeObject(forKey: oop27)
        userdefault.removeObject(forKey: oop28)
        userdefault.removeObject(forKey: oop29)
        userdefault.removeObject(forKey: oop30)
        //40
        userdefault.removeObject(forKey: oop31)
        userdefault.removeObject(forKey: oop32)
        userdefault.removeObject(forKey: oop33)
        userdefault.removeObject(forKey: oop34)
        userdefault.removeObject(forKey: oop35)
        userdefault.removeObject(forKey: oop36)
        userdefault.removeObject(forKey: oop37)
        userdefault.removeObject(forKey: oop38)
        userdefault.removeObject(forKey: oop39)
        userdefault.removeObject(forKey: oop40)
        //50
        userdefault.removeObject(forKey: oop41)
        userdefault.removeObject(forKey: oop42)
        userdefault.removeObject(forKey: oop43)
        userdefault.removeObject(forKey: oop44)
        userdefault.removeObject(forKey: oop45)
        userdefault.removeObject(forKey: oop46)
        userdefault.removeObject(forKey: oop47)
        userdefault.removeObject(forKey: oop48)
        userdefault.removeObject(forKey: oop49)
        userdefault.removeObject(forKey: oop50)
        //60
        userdefault.removeObject(forKey: oop51)
        userdefault.removeObject(forKey: oop52)
        userdefault.removeObject(forKey: oop53)
        userdefault.removeObject(forKey: oop54)
        userdefault.removeObject(forKey: oop55)
        userdefault.removeObject(forKey: oop56)
       
    }
    // add and clear button FIO
    @IBAction func add2(_ sender: UIButton) {
        if vc.arrayName.contains(SearchFIO32.text!){
            alert4(title: "Добавление пользователя", message: "Не удалось. Пользователь был ранее создан", style: .alert)
        }
        else{
            alert4(title: "Добавление пользователя", message: "Пользователь успешно добавлен", style: .alert)
            vc.arrayName.append(SearchFIO32.text!)
            userdefault.set(vc.arrayName, forKey: vc.nameArray)
        }
        connectArray()
        print(vc.arrayName)
    }
    @IBAction func deleteVariable2(_ sender: UIButton) {
        if vc.arrayName.contains(SearchFIO32.text!){
            vc.arrayName = vc.arrayName.filter(){$0 != SearchFIO32.text}
            userdefault.set(vc.arrayName, forKey: vc.nameArray)
            alert4(title: "Добавление пользователя", message: "Пользователь успешно удален", style: .alert)
            connectArray()
            SearchFIO32.text = ""
            print(vc.arrayName)
        }
        else{
            alert4(title: "Удаление невозможно", message: "Пользователя нет в списках", style: .alert)
        }
    }
    //
    fileprivate func connectArray(){
        if let abv = UserDefaults.standard.array(forKey: vc.nameArray)as?[String]{
            vc.arrayName = (UserDefaults.standard.array(forKey: vc.nameArray)as?[String])!
        }
        SearchFIO3.inlineMode = true
        SearchFIO3.startSuggestingInmediately = true
        SearchFIO3.filterStrings(vc.arrayName)
        //
        SearchFIO32.inlineMode = true
        SearchFIO32.startSuggestingInmediately = true
        SearchFIO32.filterStrings(vc.arrayName)
        
    }
    
        
    }

